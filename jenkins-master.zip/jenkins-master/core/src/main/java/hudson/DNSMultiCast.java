package hudson;

import org.kohsuke.accmod.Restricted;
import org.kohsuke.accmod.restrictions.NoExternalUse;

/**
 * @deprecated No longer does anything. Only here to prevent errors from old versions of tools like {@code JenkinsRule}.
 */
@Deprecated
@Restricted(NoExternalUse.class)
public class DNSMultiCast {

    public static boolean disabled = true;

}
